import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JSeparator;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.net.ssl.HttpsURLConnection;
import javax.swing.ImageIcon;
import javax.swing.JSpinner;
import javax.swing.JScrollBar;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseMotionAdapter;

public class Developer extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Developer frame = new Developer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Developer() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\\\Users\\\\ABAH JOSEPH ISRAEL\\\\eclipse-workspace\\\\Fpi_Result_Management\\\\src\\\\img\\\\FPI LOGO2.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 200, 700, 400);
		contentPane = new JPanel();
		contentPane.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
				int x = arg0.getXOnScreen();
				int y = arg0.getYOnScreen();
				Developer.this.setLocation(x,y);
				
			}
		});
		
		contentPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				/*int xx,xy;
				xx = arg0.getX();
				xy = arg0.getY();
				Developer.this.setLocation(xx, xy);*/
			}
		});
		contentPane.setBackground(SystemColor.textHighlight);
		contentPane.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "ABOUT DEVELOPER", TitledBorder.CENTER, TitledBorder.TOP, null, SystemColor.window));
		setContentPane(contentPane);
		
		JButton btnExit = new JButton("X");
		btnExit.setBounds(646, 9, 44, 24);
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Component quit = new JFrame("Exit");
			//if (JOptionPane.showConfirmDialog(quit, "Do you want to exit", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					//System.exit(0);
					dispose();
				//}
			}
		});
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("SIR JOH");
		lblNewLabel_1.setBackground(SystemColor.text);
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblNewLabel_1.setForeground(SystemColor.textHighlight);
		lblNewLabel_1.setBounds(537, 366, 79, 23);
		contentPane.add(lblNewLabel_1);
		
		btnExit.setHorizontalAlignment(SwingConstants.LEADING);
		btnExit.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnExit.setForeground(new Color(255, 0, 0));
		btnExit.setBackground(SystemColor.textHighlight);
		contentPane.add(btnExit);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 35, 680, 31);
		contentPane.add(separator);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.window);
		panel.setBounds(10, 39, 428, 355);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JTextPane txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha = new JTextPane();
		txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha.setForeground(Color.WHITE);
		txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha.setEditable(false);
		txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha.setText("ABAH JOSEPH ISRAEL as known by his nickname SIR JOH,\r\nis a young programmer.\r\nHe is  into software development of any kind.\r\nGet in touch with him to get your job done.");
		txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha.setBackground(SystemColor.activeCaption);
		txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha.setBounds(26, 50, 392, 187);
		panel.add(txtpnAkljasghlaAhdhajdghalAhsfkhaafjlha);
		
		JLabel lblFacebook = new JLabel("");
		lblFacebook.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			
			}
		});
		//lblFacebook.setIcon(new ImageIcon("C:\\Users\\Abah\\Desktop\\FPI\\fb2.png"));
		lblFacebook.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Facebook_48px.png"));
		lblFacebook.setBounds(10, 282, 48, 48);
		panel.add(lblFacebook);
		
		JLabel lblTwitter = new JLabel("");
		//lblTwitter.setIcon(new ImageIcon("C:\\Users\\Abah\\Desktop\\FPI\\ttwitteer.png"));
		lblTwitter.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Twitter_48px.png"));
		lblTwitter.setBounds(46, 282, 48, 48);
		panel.add(lblTwitter);
		
		JLabel lblInstagram = new JLabel("");
		//lblInstagram.setIcon(new ImageIcon("C:\\Users\\Abah\\Desktop\\FPI\\iinstagram.png"));
		lblInstagram.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Instagram_48px.png"));
		lblInstagram.setBounds(85, 282, 48, 48);
		panel.add(lblInstagram);
		
		JLabel lblSocialPlatforms = new JLabel("CONTACT");
		lblSocialPlatforms.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				}
		});
		lblSocialPlatforms.setForeground(new Color(178, 34, 34));
		lblSocialPlatforms.setFont(new Font("Arial Black", Font.BOLD, 16));
		lblSocialPlatforms.setBounds(156, 248, 93, 23);
		panel.add(lblSocialPlatforms);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("C:\\Users\\Abah\\Desktop\\FPI\\2HS.png"));
		label_2.setBounds(185, 0, 50, 47);
		panel.add(label_2);
		
		JLabel lblEmail = new JLabel("");
		lblEmail.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Gmail_50px.png"));
		lblEmail.setBounds(186, 282, 48, 48);
		panel.add(lblEmail);
		
		JLabel lblsIR = new JLabel("@s i r  j o h");
		lblsIR.setBounds(26, 330, 74, 14);
		panel.add(lblsIR);
		
		JLabel lblAbahjosephisraelgmailcom = new JLabel("abahjosephisrael@gmail.com");
		lblAbahjosephisraelgmailcom.setVerticalAlignment(SwingConstants.BOTTOM);
		lblAbahjosephisraelgmailcom.setBounds(139, 330, 184, 14);
		panel.add(lblAbahjosephisraelgmailcom);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_WhatsApp_48px.png"));
		label.setBounds(330, 282, 48, 48);
		panel.add(label);
		
		JLabel label_1 = new JLabel("08131684800");
		label_1.setBounds(318, 330, 110, 14);
		panel.add(label_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(438, 39, 252, 355);
		contentPane.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\sirjoh2.jpg"));
		setTitle("FPI Result System");
		setUndecorated(true);
	}
}
