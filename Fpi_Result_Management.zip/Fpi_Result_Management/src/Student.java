import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.border.MatteBorder;

public class Student extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	
	String Username = "Student";
	String Password = "1234";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\\\Users\\\\ABAH JOSEPH ISRAEL\\\\eclipse-workspace\\\\Fpi_Result_Management\\\\src\\\\img\\\\FPI LOGO2.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1367, 765);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 165, 0));
		contentPane.setBackground(new Color(218, 165, 32));
		contentPane.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 255, 255), new Color(0, 128, 128), new Color(244, 164, 96), new Color(255, 255, 240)), new TitledBorder(new LineBorder(new Color(47, 79, 79), 2, true), "RESULT MANAGEMENT SYSTEM", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(47, 79, 79))));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnExit = new JButton("X");
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Component quit = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(quit, "Do you want to exit", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setHorizontalAlignment(SwingConstants.LEADING);
		btnExit.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnExit.setForeground(new Color(255, 0, 0));
		btnExit.setBackground(new Color(204, 153, 0));
		btnExit.setBounds(1305, 10, 44, 24);
		contentPane.add(btnExit);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 39, 1347, 40);
		contentPane.add(separator);
		
		JLabel lblNewLabel = new JLabel("STUDENT LOGIN");
		lblNewLabel.setForeground(new Color(47, 79, 79));
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel.setBounds(613, 0, 219, 40);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 0, 0));
		panel.setBorder(null);
		panel.setBackground(new Color(47, 79, 79));
		panel.setBounds(51, 48, 1266, 641);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_User_50px.png"));
		label_1.setBounds(377, 324, 50, 50);
		panel.add(label_1);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\AVAATER2.png"));
		label.setBounds(589, 169, 97, 97);
		panel.add(label);
		
		txtUsername = new JTextField();
		txtUsername.setBackground(new Color(47, 79, 79));
		txtUsername.setBorder(new MatteBorder(0, 0, 4, 0, (Color) new Color(218, 165, 32)));
		txtUsername.setHorizontalAlignment(SwingConstants.CENTER);
		txtUsername.setFont(new Font("Arial Black", Font.BOLD, 26));
		txtUsername.setToolTipText("Enter your username here");
		txtUsername.setBounds(421, 312, 418, 49);
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBackground(new Color(47, 79, 79));
		txtPassword.setBorder(new MatteBorder(0, 0, 4, 0, (Color) new Color(218, 165, 32)));
		txtPassword.setFont(new Font("Arial Black", Font.BOLD, 26));
		txtPassword.setHorizontalAlignment(SwingConstants.CENTER);
		txtPassword.setToolTipText("Enter your password here.");
		txtPassword.setBounds(421, 385, 418, 49);
		panel.add(txtPassword);
		
		JButton button = new JButton("LOGIN");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
	
				 String password = txtPassword.getText();
				 String username = txtUsername.getText();
				if (password.equals(Password) && username.equals(Username)) {
					Result Joh = new Result();
					Joh.setVisible(true);
					dispose();
				}
				
				else
				{
				
					JOptionPane.showMessageDialog(null, "Invalid Login Details", "Login Error", JOptionPane.ERROR_MESSAGE);
					txtPassword.setText(null);
					txtUsername.setText(null);
				}
			}
		});
		button.setToolTipText("Click here to display dashboard");
		button.setFont(new Font("Arial Black", Font.BOLD, 14));
		button.setBounds(463, 501, 89, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("RESET");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				txtUsername.setText(null);
				txtPassword.setText(null);
			}
		});
		button_1.setToolTipText("Click here to here to reset username and password fields");
		button_1.setFont(new Font("Arial Black", Font.BOLD, 14));
		button_1.setBounds(583, 501, 103, 23);
		panel.add(button_1);
		
		JButton button_2 = new JButton("HOME");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				Home Joh = new Home();
				Joh.setVisible(true);
				dispose();
			}
		});
		button_2.setToolTipText("Click here to return to Home menu.");
		button_2.setFont(new Font("Arial Black", Font.BOLD, 14));
		button_2.setBounds(718, 501, 89, 23);
		panel.add(button_2);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Password_48px.png"));
		label_2.setBounds(377, 395, 48, 48);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Forgot Password?");
		label_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
				txtUsername.setText(Username);
				txtPassword.setText(Password);
			}
		});
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_3.setBounds(572, 550, 126, 17);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("All rights reserved.");
		label_4.setForeground(new Color(0, 0, 51));
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_4.setBounds(295, 360, 91, 14);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u00A9 2018");
		label_5.setForeground(new Color(0, 0, 51));
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 11));
		label_5.setBounds(320, 370, 50, 14);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("All rights reserved.");
		label_6.setForeground(new Color(0, 0, 51));
		label_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_6.setBounds(581, 700, 192, 25);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("\u00A9 2018");
		label_7.setForeground(new Color(0, 0, 51));
		label_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_7.setBounds(636, 725, 77, 25);
		contentPane.add(label_7);
		setTitle("FPI Result System");
		setUndecorated(true);
	}
}
