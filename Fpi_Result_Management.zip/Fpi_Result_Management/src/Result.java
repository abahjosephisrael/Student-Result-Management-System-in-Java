import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.DropMode;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import javax.swing.border.MatteBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Result extends JFrame {

	private JPanel contentPane;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Result frame = new Result();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Result() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\\\Users\\\\ABAH JOSEPH ISRAEL\\\\eclipse-workspace\\\\Fpi_Result_Management\\\\src\\\\img\\\\FPI LOGO2.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1367, 765);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 165, 0));
		contentPane.setBackground(new Color(218, 165, 32));
		contentPane.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 255, 255), new Color(0, 128, 128), new Color(244, 164, 96), new Color(255, 255, 240)), new TitledBorder(new LineBorder(new Color(47, 79, 79), 2, true), "RESULT MANAGEMENT SYSTEM", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(47, 79, 79))));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnExit = new JButton("X");
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Component quit = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(quit, "Do you want to exit", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setHorizontalAlignment(SwingConstants.LEADING);
		btnExit.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnExit.setForeground(new Color(255, 0, 0));
		btnExit.setBackground(new Color(204, 153, 0));
		btnExit.setBounds(1305, 10, 44, 24);
		contentPane.add(btnExit);
		
		JLabel lblNewLabel = new JLabel("RESULT CHECKER");
		lblNewLabel.setForeground(new Color(47, 79, 79));
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel.setBounds(569, 0, 219, 40);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 39, 1347, 40);
		contentPane.add(separator);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 0, 0));
		panel.setBorder(null);
		panel.setBackground(new Color(47, 79, 79));
		panel.setBounds(51, 48, 1266, 641);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(636, 51, 53, 53);
		panel.add(label);
		label.setIcon(new ImageIcon("C:\\Users\\Abah\\Desktop\\FPI\\ssaerch.png"));
		label.setVerticalAlignment(SwingConstants.TOP);
		
		JLabel label_1 = new JLabel("RESULT CHECKER");
		label_1.setForeground(new Color(218, 165, 32));
		label_1.setFont(new Font("Arial Black", Font.BOLD, 40));
		label_1.setBounds(435, 156, 436, 57);
		panel.add(label_1);
		
		JLabel lblKindlyEnterYour = new JLabel("Kindly enter your JAMB REG. NO. to check.");
		lblKindlyEnterYour.setFont(new Font("Arial Black", Font.BOLD, 30));
		lblKindlyEnterYour.setForeground(new Color(255, 255, 255));
		lblKindlyEnterYour.setBounds(255, 289, 789, 43);
		panel.add(lblKindlyEnterYour);
		
		txtSearch = new JTextField();
		txtSearch.setHorizontalAlignment(SwingConstants.CENTER);
		txtSearch.setForeground(new Color(255, 255, 255));
		txtSearch.setBackground(new Color(47, 79, 79));
		txtSearch.setBorder(new MatteBorder(0, 0, 4, 0, (Color) new Color(184, 134, 11)));
		txtSearch.setFont(new Font("Arial Black", Font.BOLD, 30));
		txtSearch.setToolTipText("Enter your JAMB REG. NO. here.");
		txtSearch.setBounds(312, 363, 664, 29);
		panel.add(txtSearch);
		txtSearch.setColumns(10);
		
		JLabel label_3 = new JLabel("");
		label_3.setToolTipText("Click to search result.");
		label_3.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Search_48px.png"));
		label_3.setVerticalAlignment(SwingConstants.TOP);
		label_3.setBounds(636, 403, 48, 48);
		panel.add(label_3);
		
		JButton btnHome = new JButton("HOME");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				Home Joh = new Home();
				Joh.setVisible(true);
				dispose();
			}
		});
		btnHome.setToolTipText("Click here to return to Home menu.");
		btnHome.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnHome.setBounds(660, 519, 89, 23);
		panel.add(btnHome);
		
		JButton btnReset = new JButton("RESET");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				txtSearch.setText(null);
			}
		});
		btnReset.setToolTipText("Click here to here to reset fields");
		btnReset.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnReset.setBounds(525, 519, 103, 23);
		panel.add(btnReset);
		
		JLabel label_2 = new JLabel("All rights reserved.");
		label_2.setForeground(new Color(0, 0, 51));
		label_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_2.setBounds(584, 700, 192, 25);
		contentPane.add(label_2);
		
		JLabel label_4 = new JLabel("\u00A9 2018");
		label_4.setForeground(new Color(0, 0, 51));
		label_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_4.setBounds(639, 725, 77, 25);
		contentPane.add(label_4);
		
		
		setTitle("FPI Result System");
		setUndecorated(true);
	}
}
