import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.DefaultComboBoxModel;

public class AdminDb extends JFrame {

	private JPanel contentPane;
	private JTextField txtStudentId;
	private JTextField txtFirstname;
	private JTextField txtSurname;
	private JTextField txtCourse3;
	private JTextField txtCourse1;
	private JTextField txtCourse2;
	private JTextField txtCourse6;
	private JTextField txtCourse4;
	private JTextField txtCourse5;
	private JTextField txtCourse7;
	private JTextField txtCourse8;
	private JTextField txtAverage;
	private JTextField txtTotal;
	private JTextField txtRanking;
	private JTable table;
	private JTextField txtcourse1;
	private JTextField txtcourse2;
	private JTextField txtcourse3;
	private JTextField txtcourse4;
	private JTextField txtcourse5;
	private JTextField txtcourse6;
	private JTextField txtcourse7;
	private JTextField txtcourse8;
	private JTextField txtCourse9;
	private JTextField txtcourse9;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminDb frame = new AdminDb();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminDb() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\\\Users\\\\ABAH JOSEPH ISRAEL\\\\eclipse-workspace\\\\Fpi_Result_Management\\\\src\\\\img\\\\FPI LOGO2.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1367, 765);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 165, 0));
		contentPane.setBackground(new Color(218, 165, 32));
		contentPane.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 255, 255), new Color(0, 128, 128), new Color(244, 164, 96), new Color(255, 255, 240)), new TitledBorder(new LineBorder(new Color(47, 79, 79), 2, true), "RESULT MANAGEMENT SYSTEM", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(47, 79, 79))));
		setContentPane(contentPane);
		
		
		JButton btnExit = new JButton("X");
		btnExit.setBounds(1305, 10, 44, 24);
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Component quit = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(quit, "Do you want to exit", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		contentPane.setLayout(null);
		btnExit.setHorizontalAlignment(SwingConstants.LEADING);
		btnExit.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnExit.setForeground(new Color(255, 0, 0));
		btnExit.setBackground(new Color(204, 153, 0));
		contentPane.add(btnExit);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 39, 1347, 40);
		contentPane.add(separator);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(218, 165, 32));
		panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 128, 128), 5), "STUDENT RESULT ENTRY", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 128, 128)));
		panel.setBounds(20, 50, 659, 402);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Student_ID");
		lblNewLabel.setBounds(24, 26, 80, 14);
		panel.add(lblNewLabel);
		
		txtStudentId = new JTextField();
		txtStudentId.setBounds(101, 20, 172, 20);
		panel.add(txtStudentId);
		txtStudentId.setColumns(10);
		
		txtFirstname = new JTextField();
		txtFirstname.setColumns(10);
		txtFirstname.setBounds(101, 48, 172, 20);
		panel.add(txtFirstname);
		
		JLabel lblFirstname = new JLabel("Firstname");
		lblFirstname.setBounds(24, 54, 80, 14);
		panel.add(lblFirstname);
		
		txtSurname = new JTextField();
		txtSurname.setColumns(10);
		txtSurname.setBounds(101, 79, 172, 20);
		panel.add(txtSurname);
		
		JLabel lblSurname = new JLabel("Surname");
		lblSurname.setBounds(24, 85, 80, 14);
		panel.add(lblSurname);
		
		txtCourse3 = new JTextField();
		txtCourse3.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse3.setColumns(10);
		txtCourse3.setBounds(448, 91, 182, 20);
		panel.add(txtCourse3);
		
		txtCourse1 = new JTextField();
		txtCourse1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse1.setColumns(10);
		txtCourse1.setBounds(448, 32, 182, 20);
		panel.add(txtCourse1);
		
		txtCourse2 = new JTextField();
		txtCourse2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse2.setColumns(10);
		txtCourse2.setBounds(448, 60, 182, 20);
		panel.add(txtCourse2);
		
		txtCourse6 = new JTextField();
		txtCourse6.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse6.setColumns(10);
		txtCourse6.setBounds(448, 181, 182, 20);
		panel.add(txtCourse6);
		
		txtCourse4 = new JTextField();
		txtCourse4.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
			
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse4.setColumns(10);
		txtCourse4.setBounds(448, 122, 182, 20);
		panel.add(txtCourse4);
		
		txtCourse5 = new JTextField();
		txtCourse5.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse5.setColumns(10);
		txtCourse5.setBounds(448, 150, 182, 20);
		panel.add(txtCourse5);
		
		txtCourse7 = new JTextField();
		txtCourse7.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse7.setColumns(10);
		txtCourse7.setBounds(448, 213, 182, 20);
		panel.add(txtCourse7);
		
		txtCourse8 = new JTextField();
		txtCourse8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent evt) {
				
				char iNumber = evt.getKeyChar();
				if(!(Character.isDigit(iNumber))
						||(iNumber==KeyEvent.VK_BACK_SPACE)
						||(iNumber==KeyEvent.VK_DELETE)) {
					evt.consume();
				}
			}
		});
		txtCourse8.setColumns(10);
		txtCourse8.setBounds(448, 241, 182, 20);
		panel.add(txtCourse8);
		
		JComboBox cmbLevel = new JComboBox();
		cmbLevel.setModel(new DefaultComboBoxModel(new String[] {"Select Level","ND1", "ND2", "HND1", "HND2"}));
		cmbLevel.setBounds(101, 110, 172, 20);
		panel.add(cmbLevel);
		
		JComboBox cmbSemester = new JComboBox();
		cmbSemester.setModel(new DefaultComboBoxModel(new String[] {"Select Semester", "First", "Second"}));
		cmbSemester.setBounds(101, 141, 172, 20);
		panel.add(cmbSemester);
		
		
		JLabel lblLevel = new JLabel("Level");
		lblLevel.setBounds(24, 116, 80, 14);
		panel.add(lblLevel);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(24, 228, 249, 20);
		panel.add(separator_1);
		
		txtAverage = new JTextField();
		txtAverage.setEditable(false);
		txtAverage.setColumns(10);
		txtAverage.setBounds(101, 269, 172, 20);
		panel.add(txtAverage);
		
		txtTotal = new JTextField();
		txtTotal.setEditable(false);
		txtTotal.setColumns(10);
		txtTotal.setBounds(101, 241, 172, 20);
		panel.add(txtTotal);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setBounds(24, 247, 80, 14);
		panel.add(lblTotal);
		
		JLabel lblAverage = new JLabel("Average");
		lblAverage.setBounds(24, 275, 80, 14);
		panel.add(lblAverage);
		
		JLabel lblRanking = new JLabel("Ranking");
		lblRanking.setBounds(24, 306, 80, 14);
		panel.add(lblRanking);
		
		txtRanking = new JTextField();
		txtRanking.setEditable(false);
		txtRanking.setColumns(10);
		txtRanking.setBounds(101, 300, 172, 20);
		panel.add(txtRanking);
		
		txtcourse1 = new JTextField();
		txtcourse1.setBorder(null);
		txtcourse1.setBackground(new Color(218, 165, 32));
		txtcourse1.setEditable(false);
		txtcourse1.setBounds(379, 32, 59, 20);
		panel.add(txtcourse1);
		txtcourse1.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.setFont(new Font("Tahoma", Font.BOLD, 8));
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				Object level = cmbLevel.getSelectedItem();
				Object semester = cmbSemester.getSelectedItem();
				if((level.equals("ND1"))&&(semester.equals("First"))) {
					txtcourse1.setText("COM111");
					txtcourse2.setText("COM112");
					txtcourse3.setText("COM113");
					txtcourse4.setText("STA111");
					txtcourse5.setText("STA112");
					txtcourse6.setText("MTH111");
					txtcourse7.setText("MTH112");
					txtcourse8.setText("OTM112");
					txtcourse9.setText("GNS127");
					}
				else if((level.equals("ND1"))&&(semester.equals("Second"))) {
					txtcourse1.setText("COM121");
					txtcourse2.setText("COM122");
					txtcourse3.setText("COM123");
					txtcourse4.setText("COM124");
					txtcourse5.setText("COM125");
					txtcourse6.setText("COM126");
					txtcourse7.setText("EED126");
					txtcourse8.setText("GNS128");
					txtcourse9.setText(null);
					txtCourse9.setText("-");
					
				}
				else if((level.equals("ND2"))&&(semester.equals("First"))) {
					txtcourse1.setText("COM211");
					txtcourse2.setText("COM212");
					txtcourse3.setText("COM213");
					txtcourse4.setText("COM214");
					txtcourse5.setText("COM215");
					txtcourse6.setText("COM216");
					txtcourse7.setText("OTM216");
					txtcourse8.setText("EED216");
					txtcourse9.setText(null);
					txtCourse9.setText("-");
					
				}
				else if((level.equals("ND2"))&&(semester.equals("Second"))) {
					txtcourse1.setText("COM221");
					txtcourse2.setText("COM222");
					txtcourse3.setText("COM223");
					txtcourse4.setText("COM224");
					txtcourse5.setText("COM225");
					txtcourse6.setText("COM226");
					txtcourse7.setText("COM229");
					txtcourse8.setText("COM229");
					txtcourse9.setText(null);
					txtCourse9.setText("-");
					
				}
				else if((level.equals("HND1"))&&(semester.equals("First"))) {
					txtcourse1.setText("COM311");
					txtcourse2.setText("COM312");
					txtcourse3.setText("COM313");
					txtcourse4.setText("COM314");
					txtcourse5.setText("STA315");
					txtcourse6.setText("STA311");
					txtcourse7.setText("OTM315");
					txtcourse8.setText(null);
					txtcourse9.setText(null);
					txtCourse8.setText("-");
					txtCourse9.setText("-");
					
				}
				else if((level.equals("HND1"))&&(semester.equals("Second"))) {
					txtcourse1.setText("COM321");
					txtcourse2.setText("COM322");
					txtcourse3.setText("COM323");
					txtcourse4.setText("COM324");
					txtcourse5.setText("STA326");
					txtcourse6.setText("STA321");
					txtcourse7.setText("OTM412");
					txtcourse8.setText(null);
					txtcourse9.setText(null);
					txtCourse8.setText("-");
					txtCourse9.setText("-");
					
				}
				else if((level.equals("HND2"))&&(semester.equals("First"))) {
					txtcourse1.setText("COM412");
					txtcourse2.setText("COM413");
					txtcourse3.setText("COM414");
					txtcourse4.setText("COM415");
					txtcourse5.setText("COM416");
					txtcourse6.setText("STA411");
					txtcourse7.setText(null);
					txtcourse8.setText(null);
					txtcourse9.setText(null);
					txtCourse7.setText("-");
					txtCourse8.setText("-");
					txtCourse9.setText("-");
					
				}
				else if((level.equals("HND2"))&&(semester.equals("Second"))) {
					txtcourse1.setText("COM422");
					txtcourse2.setText("COM423");
					txtcourse3.setText("COM424");
					txtcourse4.setText("COM425");
					txtcourse5.setText("COM426");
					txtcourse6.setText("COM429");
					txtcourse7.setText(null);
					txtcourse8.setText(null);
					txtcourse9.setText(null);
					txtCourse7.setText("-");
					txtCourse8.setText("-");
					txtCourse9.setText("-");
					
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Please select a level and semester.", 
							"Student Result System", JOptionPane.OK_OPTION);
					
				}
			}
		});
		btnOk.setBounds(161, 194, 47, 23);
		panel.add(btnOk);
		
		txtcourse2 = new JTextField();
		txtcourse2.setEditable(false);
		txtcourse2.setColumns(10);
		txtcourse2.setBorder(null);
		txtcourse2.setBackground(new Color(218, 165, 32));
		txtcourse2.setBounds(379, 57, 59, 20);
		panel.add(txtcourse2);
		
		txtcourse3 = new JTextField();
		txtcourse3.setEditable(false);
		txtcourse3.setColumns(10);
		txtcourse3.setBorder(null);
		txtcourse3.setBackground(new Color(218, 165, 32));
		txtcourse3.setBounds(379, 91, 59, 20);
		panel.add(txtcourse3);
		
		txtcourse4 = new JTextField();
		txtcourse4.setEditable(false);
		txtcourse4.setColumns(10);
		txtcourse4.setBorder(null);
		txtcourse4.setBackground(new Color(218, 165, 32));
		txtcourse4.setBounds(379, 122, 59, 20);
		panel.add(txtcourse4);
		
		txtcourse5 = new JTextField();
		txtcourse5.setEditable(false);
		txtcourse5.setColumns(10);
		txtcourse5.setBorder(null);
		txtcourse5.setBackground(new Color(218, 165, 32));
		txtcourse5.setBounds(379, 150, 59, 20);
		panel.add(txtcourse5);
		
		txtcourse6 = new JTextField();
		txtcourse6.setEditable(false);
		txtcourse6.setColumns(10);
		txtcourse6.setBorder(null);
		txtcourse6.setBackground(new Color(218, 165, 32));
		txtcourse6.setBounds(379, 181, 59, 20);
		panel.add(txtcourse6);
		
		txtcourse7 = new JTextField();
		txtcourse7.setEditable(false);
		txtcourse7.setColumns(10);
		txtcourse7.setBorder(null);
		txtcourse7.setBackground(new Color(218, 165, 32));
		txtcourse7.setBounds(379, 213, 59, 20);
		panel.add(txtcourse7);
		
		txtcourse8 = new JTextField();
		txtcourse8.setEditable(false);
		txtcourse8.setColumns(10);
		txtcourse8.setBorder(null);
		txtcourse8.setBackground(new Color(218, 165, 32));
		txtcourse8.setBounds(379, 241, 59, 20);
		panel.add(txtcourse8);
		
		
		
		
		JLabel lblSemester = new JLabel("Semester");
		lblSemester.setBounds(24, 147, 80, 14);
		panel.add(lblSemester);
		
		JLabel lblNoteClickThe = new JLabel("Note: Click the \"OK\" button after selecting Level and");
		lblNoteClickThe.setVerticalTextPosition(SwingConstants.TOP);
		lblNoteClickThe.setForeground(new Color(255, 0, 0));
		lblNoteClickThe.setBounds(24, 166, 307, 23);
		panel.add(lblNoteClickThe);
		
		JLabel lblSemester_1 = new JLabel("Semester");
		lblSemester_1.setForeground(Color.RED);
		lblSemester_1.setBounds(24, 184, 100, 23);
		panel.add(lblSemester_1);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setBounds(101, 133, 172, 9);
		panel.add(separator_5);
		
		txtCourse9 = new JTextField();
		txtCourse9.setColumns(10);
		txtCourse9.setBounds(448, 272, 182, 20);
		panel.add(txtCourse9);
		
		txtcourse9 = new JTextField();
		txtcourse9.setEditable(false);
		txtcourse9.setColumns(10);
		txtcourse9.setBorder(null);
		txtcourse9.setBackground(new Color(218, 165, 32));
		txtcourse9.setBounds(379, 272, 59, 20);
		panel.add(txtcourse9);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(218, 165, 32));
		panel_2.setBorder(new TitledBorder(new LineBorder(new Color(0, 128, 128), 5), "STUDENT TRANSCRIPTS", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 128, 128)));
		panel_2.setBounds(690, 50, 659, 402);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 22, 639, 369);
		panel_2.add(scrollPane_1);
		
		JTextArea jtxtTranscript = new JTextArea();
		scrollPane_1.setViewportView(jtxtTranscript);
		jtxtTranscript.setEditable(false);
		jtxtTranscript.setFont(new Font("Arial Black", Font.BOLD, 15));
		jtxtTranscript.setBackground(new Color(218, 165, 32));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 474, 1329, 162);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
				
			new Object[][] {
			},
			new String[] {
				"Student_ID", "Level", "Semester", "course1", "course2", "course3", "course4", "course5", "course6", "course7", "course8","course9", "Total", "Average", "Ranking"
			}
			
		));
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(30, 463, 1319, 24);
		contentPane.add(separator_2);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(30, 640, 1319, 24);
		contentPane.add(separator_3);
		
		JButton btnAddResult = new JButton("Add Result");
		btnAddResult.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String course1 = txtCourse1.getText();
				String course2 = txtCourse2.getText();
				String course3 = txtCourse3.getText();
				String course4 = txtCourse4.getText();
				String course7 = txtCourse7.getText();
				String course8 = txtCourse8.getText();
				String course9 = txtCourse9.getText();
				
				if((course1.equals(""))
					||(course2.equals(""))
					||(course3.equals(""))
					||(course4.equals("")))
					{
					
					JOptionPane.showMessageDialog(null, "Field must not be empty\nAt least Four courses must be entered.", 
							"Student Result System", JOptionPane.OK_OPTION);
					
					}else if((course7.equals("-"))
						&&(course8.equals("-"))
						&&(course9.equals("-")))
						{
					double [] R = new double[14];
					R[0] = Double.parseDouble(txtCourse1.getText());
					R[1] = Double.parseDouble(txtCourse2.getText());
					R[2] = Double.parseDouble(txtCourse3.getText());
					R[3] = Double.parseDouble(txtCourse4.getText());
					R[4] = Double.parseDouble(txtCourse5.getText());
					R[5] = Double.parseDouble(txtCourse6.getText());
					
					R[9] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5])/6;
					R[10] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5]);
					String Average = String.format("%.0f",R[9]);
					txtAverage.setText(Average);
					
					String iTotal= String.format("%.0f",R[10]);
					txtTotal.setText(iTotal);
					
					if(R[10]>=700) {
						txtRanking.setText("Distinction");
					}else if(R[10]>=600) {
						txtRanking.setText("Upper Credit");
					}else if(R[10]>=500) {
						txtRanking.setText("Lower Credit");
					}else if(R[10]>=400) {
						txtRanking.setText("Pass");
					}else if(R[10]>=300) {
						txtRanking.setText("Fail");
					}
									
					//=============================================================
					DefaultTableModel model = (DefaultTableModel) table.getModel();
					model.addRow(new Object[] {
							txtStudentId.getText(),
							cmbLevel.getSelectedItem(),
							cmbSemester.getSelectedItem(),
							txtCourse1.getText(),
							txtCourse2.getText(),
							txtCourse3.getText(),
							txtCourse4.getText(),
							txtCourse5.getText(),
							txtCourse6.getText(),
							txtCourse7.getText(),
							txtCourse8.getText(),
							txtCourse9.getText(),
							txtTotal.getText(),
							txtAverage.getText(),
							txtRanking.getText(),
					});
					
					}
					else if((course8.equals("-"))
							&&(course9.equals("-")))
							{
						double [] R = new double[14];
						R[0] = Double.parseDouble(txtCourse1.getText());
						R[1] = Double.parseDouble(txtCourse2.getText());
						R[2] = Double.parseDouble(txtCourse3.getText());
						R[3] = Double.parseDouble(txtCourse4.getText());
						R[4] = Double.parseDouble(txtCourse5.getText());
						R[5] = Double.parseDouble(txtCourse6.getText());
						R[6] = Double.parseDouble(txtCourse7.getText());
						
						R[9] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5]+ R[6])/7;
						R[10] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5]+ R[6]);
						String Average = String.format("%.0f",R[9]);
						txtAverage.setText(Average);
						
						String iTotal= String.format("%.0f",R[10]);
						txtTotal.setText(iTotal);
						
						if(R[10]>=700) {
							txtRanking.setText("Distinction");
						}else if(R[10]>=600) {
							txtRanking.setText("Upper Credit");
						}else if(R[10]>=500) {
							txtRanking.setText("Lower Credit");
						}else if(R[10]>=400) {
							txtRanking.setText("Pass");
						}else if(R[10]>=300) {
							txtRanking.setText("Fail");
						}				
						//=============================================================
						DefaultTableModel model = (DefaultTableModel) table.getModel();
						model.addRow(new Object[] {
								txtStudentId.getText(),
								cmbLevel.getSelectedItem(),
								cmbSemester.getSelectedItem(),
								txtCourse1.getText(),
								txtCourse2.getText(),
								txtCourse3.getText(),
								txtCourse4.getText(),
								txtCourse5.getText(),
								txtCourse6.getText(),
								txtCourse7.getText(),
								txtCourse8.getText(),
								txtCourse9.getText(),
								txtTotal.getText(),
								txtAverage.getText(),
								txtRanking.getText(),
						});	
						
					}
					else if((course9.equals("-")))
							{
						double [] R = new double[14];
						R[0] = Double.parseDouble(txtCourse1.getText());
						R[1] = Double.parseDouble(txtCourse2.getText());
						R[2] = Double.parseDouble(txtCourse3.getText());
						R[3] = Double.parseDouble(txtCourse4.getText());
						R[4] = Double.parseDouble(txtCourse5.getText());
						R[5] = Double.parseDouble(txtCourse6.getText());
						R[6] = Double.parseDouble(txtCourse7.getText());
						R[7] = Double.parseDouble(txtCourse8.getText());
						R[9] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5] + R[6] + R[7] )/8;
						R[10] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5]+ R[6]+ R[7]);
						String Average = String.format("%.0f",R[9]);
						txtAverage.setText(Average);
						
						String iTotal= String.format("%.0f",R[10]);
						txtTotal.setText(iTotal);
						
						if(R[10]>=700) {
							txtRanking.setText("Distinction");
						}else if(R[10]>=600) {
							txtRanking.setText("Upper Credit");
						}else if(R[10]>=500) {
							txtRanking.setText("Lower Credit");
						}else if(R[10]>=400) {
							txtRanking.setText("Pass");
						}else if(R[10]>=300) {
							txtRanking.setText("Fail");
						}				
						//=============================================================
						DefaultTableModel model = (DefaultTableModel) table.getModel();
						model.addRow(new Object[] {
								txtStudentId.getText(),
								cmbLevel.getSelectedItem(),
								cmbSemester.getSelectedItem(),
								txtCourse1.getText(),
								txtCourse2.getText(),
								txtCourse3.getText(),
								txtCourse4.getText(),
								txtCourse5.getText(),
								txtCourse6.getText(),
								txtCourse7.getText(),
								txtCourse8.getText(),
								txtCourse9.getText(),
								txtTotal.getText(),
								txtAverage.getText(),
								txtRanking.getText(),
						});				
						
					}
							
				else {
					
				double [] R = new double[14];
				R[0] = Double.parseDouble(txtCourse1.getText());
				R[1] = Double.parseDouble(txtCourse2.getText());
				R[2] = Double.parseDouble(txtCourse3.getText());
				R[3] = Double.parseDouble(txtCourse4.getText());
				R[4] = Double.parseDouble(txtCourse5.getText());
				R[5] = Double.parseDouble(txtCourse6.getText());
				R[6] = Double.parseDouble(txtCourse7.getText());
				R[7] = Double.parseDouble(txtCourse8.getText());
				R[8] = Double.parseDouble(txtCourse9.getText());
				
				R[9] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5] + R[6] + R[7] +R[8])/8;
				R[10] = (R[0] + R[1] +R[2] + R[3] + R[4] + R[5] + R[6] + R[7]);
				String Average = String.format("%.0f",R[9]);
				txtAverage.setText(Average);
				
				String iTotal= String.format("%.0f",R[10]);
				txtTotal.setText(iTotal);
				
				if(R[10]>=700) {
					txtRanking.setText("Distinction");
				}else if(R[10]>=600) {
					txtRanking.setText("Upper Credit");
				}else if(R[10]>=500) {
					txtRanking.setText("Lower Credit");
				}else if(R[10]>=400) {
					txtRanking.setText("Pass");
				}else if(R[10]>=300) {
					txtRanking.setText("Fail");
				}				
				//=============================================================
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.addRow(new Object[] {
						txtStudentId.getText(),
						cmbLevel.getSelectedItem(),
						cmbSemester.getSelectedItem(),
						txtCourse1.getText(),
						txtCourse2.getText(),
						txtCourse3.getText(),
						txtCourse4.getText(),
						txtCourse5.getText(),
						txtCourse6.getText(),
						txtCourse7.getText(),
						txtCourse8.getText(),
						txtCourse9.getText(),
						txtTotal.getText(),
						txtAverage.getText(),
						txtRanking.getText(),
							
						
				});
				//=============================================================
				}}
			
		});
		btnAddResult.setBounds(310, 650, 103, 23);
		contentPane.add(btnAddResult);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				//=============================================================
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(table.getSelectedRow()== -1) {
					if(table.getRowCount()== 0) {
						JOptionPane.showMessageDialog(null, "No data to delete", "Student Result System", JOptionPane.OK_OPTION);
					}else {
						JOptionPane.showMessageDialog(null, "No data to delete", "Student Result System", JOptionPane.OK_OPTION);
					}
				}else {
					if (JOptionPane.showConfirmDialog(null, "The selected Data will be removed.\nDo you want to continue?", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
						
					model.removeRow(table.getSelectedRow());
				}
				}
				//=============================================================
				
			}
		});
		btnDelete.setBounds(465, 650, 103, 23);
		contentPane.add(btnDelete);
		
		JButton btnTranscript = new JButton("Transcript");
		btnTranscript.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String course1 = txtCourse1.getText();
				String course2 = txtCourse2.getText();
				String course3 = txtCourse3.getText();
				String course4 = txtCourse4.getText();
				String total = txtTotal.getText();
				String average = txtAverage.getText();
				
				if((course1.equals(""))
					||(course2.equals(""))
					||(course3.equals(""))
					||(course4.equals(""))
					||(total.equals(""))
					||(average.equals("")))
					 {
					
					JOptionPane.showMessageDialog(null, "Field must not be empty", 
							"Student Result System", JOptionPane.OK_OPTION);
					
				}else {
			
				//====================================================================
				
				jtxtTranscript.append( "\t    Student Semester Result\n"
						+"==============================================\n"
						+"Name:\t" + txtSurname.getText() + " " + txtFirstname.getText()
						+"\nLevel:\t"+cmbLevel.getSelectedItem()
						+ "\nSemester:\t" + cmbSemester.getSelectedItem()
						+"\n________________________________________________"
						+"\nCourses \t\t\tScores"
						+"\n________________________________________________"
						+"\n"+txtcourse1.getText()+": \t\t\t" + txtCourse1.getText()
						+"\n"+txtcourse2.getText()+": \t\t\t" + txtCourse2.getText()
						+"\n"+txtcourse3.getText()+": \t\t\t" + txtCourse3.getText()
						+"\n"+txtcourse4.getText()+": \t\t\t" + txtCourse4.getText()
						+"\n"+txtcourse5.getText()+": \t\t\t" + txtCourse5.getText()
						+"\n"+txtcourse6.getText()+": \t\t\t" + txtCourse6.getText()
						+"\n"+txtcourse7.getText()+": \t\t\t" + txtCourse7.getText()
						+"\n"+txtcourse8.getText()+": \t\t\t" + txtCourse8.getText()
						+"\n"+txtcourse9.getText()+": \t\t\t" + txtCourse9.getText()
						+"\n==============================================\n"
						+"\nTotal Score: \t\t\t" + txtTotal.getText()
						+"\nAverage: \t\t\t" + txtAverage.getText()
						+"\nRanking: \t\t\t" + txtRanking.getText()
						+"\n\n\n"
						);
				//====================================================================
			}}
		});
		btnTranscript.setBounds(616, 650, 103, 23);
		contentPane.add(btnTranscript);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				txtStudentId.setText(null);
				cmbLevel.setSelectedItem("Select Level");
				cmbSemester.setSelectedItem("Select Semester");
				txtFirstname.setText(null);
				txtSurname.setText(null);
				txtTotal.setText(null);
				txtAverage.setText(null);
				txtRanking.setText(null);
				txtCourse2.setText(null);
				txtCourse1.setText(null);
				txtCourse8.setText(null);
				txtCourse3.setText(null);
				txtCourse5.setText(null);
				txtCourse6.setText(null);
				txtCourse4.setText(null);
				txtCourse7.setText(null);
				txtCourse8.setText(null);
				txtCourse9.setText(null);
				jtxtTranscript.setText(null);
				//================================================
				//Course code reset
				txtcourse1.setText(null);
				txtcourse2.setText(null);
				txtcourse3.setText(null);
				txtcourse4.setText(null);
				txtcourse5.setText(null);
				txtcourse6.setText(null);
				txtcourse7.setText(null);
				txtcourse8.setText(null);
				txtcourse9.setText(null);
				
				/*JTextField temp = null;
				for(java.awt.Component c : panel.getComponents()) {
					if(c.getClass().toString().contains("javax.swing.JTextFeild")) {
						temp=(JTextField) c ;
						temp.setText(null);
					}
				}*/
			}
		});
		btnReset.setBounds(764, 650, 103, 23);
		contentPane.add(btnReset);
		
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				if (JOptionPane.showConfirmDialog(null, "Do you want to Logout?", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					Home Joh = new Home();
				Joh.setVisible(true);
				dispose();
				}
				
			}
		});
		btnHome.setBounds(906, 650, 103, 23);
		contentPane.add(btnHome);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBounds(30, 680, 1319, 24);
		contentPane.add(separator_4);
		
		JLabel lblAdminDashboard = new JLabel("ADMIN DASHBOARD");
		lblAdminDashboard.setForeground(new Color(47, 79, 79));
		lblAdminDashboard.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblAdminDashboard.setBounds(543, -1, 264, 40);
		contentPane.add(lblAdminDashboard);
		
		JLabel label = new JLabel("\u00A9 2018");
		label.setForeground(new Color(0, 0, 51));
		label.setFont(new Font("Tahoma", Font.BOLD, 20));
		label.setBounds(630, 718, 77, 25);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("All rights reserved.");
		label_1.setForeground(new Color(0, 0, 51));
		label_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_1.setBounds(575, 693, 192, 25);
		contentPane.add(label_1);
		
		
		setTitle("FPI Result System");
		setUndecorated(true);
	}
}
