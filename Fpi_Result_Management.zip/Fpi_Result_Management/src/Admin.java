import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;
import java.sql.*;
public class Admin extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	String Username = "Admin";
	String Password = "1234";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\src\\img\\FPI LOGO2.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1367, 765);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 165, 0));
		contentPane.setBackground(new Color(218, 165, 32));
		contentPane.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 255, 255), new Color(0, 128, 128), new Color(244, 164, 96), new Color(255, 255, 240)), new TitledBorder(new LineBorder(new Color(47, 79, 79), 2, true), "RESULT MANAGEMENT SYSTEM", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(47, 79, 79))));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnExit = new JButton("X");
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Component quit = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(quit, "Do you want to exit", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setHorizontalAlignment(SwingConstants.LEADING);
		btnExit.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnExit.setForeground(new Color(255, 0, 0));
		btnExit.setBackground(new Color(204, 153, 0));
		btnExit.setBounds(1305, 10, 44, 24);
		contentPane.add(btnExit);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 39, 1347, 40);
		contentPane.add(separator);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 0, 0));
		panel.setBorder(null);
		panel.setBackground(new Color(47, 79, 79));
		panel.setBounds(51, 48, 1266, 641);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(589, 130, 97, 97);
		label_1.setVerticalAlignment(SwingConstants.TOP);
		label_1.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\AVAATER2.png"));
		panel.add(label_1);
		
		txtUsername = new JTextField();
		txtUsername.setBackground(new Color(47, 79, 79));
		txtUsername.setBorder(new MatteBorder(0, 0, 5, 0, (Color) new Color(184, 134, 11)));
		txtUsername.setBounds(421, 312, 418, 49);
		txtUsername.setHorizontalAlignment(SwingConstants.CENTER);
		txtUsername.setFont(new Font("Arial Black", Font.BOLD, 40));
		txtUsername.setToolTipText("Enter your username here");
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBackground(new Color(47, 79, 79));
		txtPassword.setBorder(new MatteBorder(0, 0, 5, 0, (Color) new Color(184, 134, 11)));
		txtPassword.setBounds(421, 385, 418, 49);
		txtPassword.setFont(new Font("Arial Black", Font.BOLD, 40));
		txtPassword.setHorizontalAlignment(SwingConstants.CENTER);
		txtPassword.setToolTipText("Enter your password here.");
		panel.add(txtPassword);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setBounds(463, 501, 89, 23);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			
				
				
				
				
				 String password = txtPassword.getText();
				 String username = txtUsername.getText();
				if (password.equals(Password) && username.equals(Username)) {
					AdminDb Joh = new AdminDb();
					Joh.setVisible(true);
					dispose();
				}
				
				else
				{
				
					JOptionPane.showMessageDialog(null, "Invalid Login Details", "Login Error", JOptionPane.ERROR_MESSAGE);
					txtPassword.setText(null);
					txtUsername.setText(null);
				}
				
			}
			public void run() {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection conn = null;
					conn = DriverManager.getConnection("jdbc:mysql://localhost/login","root","");
					JOptionPane.showMessageDialog(null,"Database is connected successfully!");
					conn.close();
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(null,"Error Connnecting to database! "+e);
				}
			}
		});
		btnLogin.setToolTipText("Click here to display dashboard");
		btnLogin.setFont(new Font("Arial Black", Font.BOLD, 14));
		panel.add(btnLogin);
		
		JButton btnReset = new JButton("RESET");
		btnReset.setBounds(583, 501, 103, 23);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				txtUsername.setText(null);
				txtPassword.setText(null);
			}
		});
		btnReset.setToolTipText("Click here to here to reset username and password fields");
		btnReset.setFont(new Font("Arial Black", Font.BOLD, 14));
		panel.add(btnReset);
		
		JButton btnHome = new JButton("HOME");
		btnHome.setBounds(718, 501, 89, 23);
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Home Joh = new Home();
				Joh.setVisible(true);
				dispose();
			}
		});
		btnHome.setToolTipText("Click here to return to Home menu.");
		btnHome.setFont(new Font("Arial Black", Font.BOLD, 14));
		panel.add(btnHome);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(374, 326, 48, 48);
		label_2.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_User_Male_48px.png"));
		panel.add(label_2);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(374, 396, 48, 48);
		label_5.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\img\\icons8_Password_48px.png"));
		panel.add(label_5);
		
		JLabel lblForgotPassword = new JLabel("Forgot Password?");
		lblForgotPassword.setBounds(572, 550, 126, 17);
		lblForgotPassword.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			
				txtUsername.setText(Username);
				txtPassword.setText(Password);
				
			}
		});
		lblForgotPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblForgotPassword.setForeground(new Color(218, 165, 32));
		panel.add(lblForgotPassword);
		
		JLabel lblNewLabel = new JLabel("ADMIN LOGIN");
		lblNewLabel.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
			}
		});
		lblNewLabel.setForeground(new Color(47, 79, 79));
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel.setBounds(613, 0, 219, 40);
		contentPane.add(lblNewLabel);
		
		JLabel label = new JLabel("\u00A9 2018");
		label.setForeground(new Color(0, 0, 51));
		label.setFont(new Font("Tahoma", Font.BOLD, 20));
		label.setBounds(637, 725, 77, 25);
		contentPane.add(label);
		
		JLabel label_3 = new JLabel("All rights reserved.");
		label_3.setForeground(new Color(0, 0, 51));
		label_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_3.setBounds(582, 700, 192, 25);
		contentPane.add(label_3);
		
		setTitle("FPI Result System");
		setUndecorated(true);
		
		
	}
}
