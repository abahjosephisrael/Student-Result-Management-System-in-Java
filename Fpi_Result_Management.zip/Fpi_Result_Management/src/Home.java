import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.LineBorder;

public class Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\src\\img\\FPI LOGO2.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1367, 765);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 165, 0));
		contentPane.setBackground(new Color(218, 165, 32));
		contentPane.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 255, 255), new Color(0, 128, 128), new Color(244, 164, 96), new Color(255, 255, 240)), new TitledBorder(new LineBorder(new Color(0, 0, 0), 2, true), "RESULT MANAGEMENT SYSTEM", TitledBorder.CENTER, TitledBorder.BOTTOM, null, new Color(47, 79, 79))));		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBounds(584, 39, 185, 185);
		label.setIcon(new ImageIcon(Home.class.getResource("/img/FPI LOGO2.png")));
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("FEDERAL POLYTECHNIC IDAH");
		label_1.setBounds(342, 218, 653, 47);
		label_1.setBackground(new Color(70, 130, 180));
		label_1.setForeground(new Color(0, 51, 102));
		label_1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 40));
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("KOGI STATE");
		label_2.setBounds(555, 276, 270, 47);
		label_2.setBackground(new Color(70, 130, 180));
		label_2.setForeground(new Color(0, 51, 102));
		label_2.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 40));
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Motto:");
		label_3.setBounds(635, 349, 81, 31);
		label_3.setForeground(new Color(255, 255, 255));
		label_3.setFont(new Font("Tahoma", Font.BOLD, 25));
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Technology for self reliance");
		label_4.setBounds(516, 379, 347, 31);
		label_4.setForeground(new Color(255, 255, 255));
		label_4.setFont(new Font("Tahoma", Font.BOLD, 25));
		contentPane.add(label_4);
		
		JButton button = new JButton("ADMIN");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Admin Joh = new Admin();
				Joh.setVisible(true);
				dispose();
			}
		});
		button.setToolTipText("Login as Admin to manage student results");
		button.setBounds(283, 598, 282, 39);
		button.setForeground(new Color(255, 0, 0));
		button.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16));
		button.setBackground(new Color(176, 196, 222));
		contentPane.add(button);
		
		JButton button_1 = new JButton("STUDENT");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Student Joh = new Student();
				Joh.setVisible(true);
				dispose();				
			}
		});
		button_1.setToolTipText("Login as student to check result.");
		button_1.setBounds(786, 598, 282, 39);
		button_1.setForeground(new Color(255, 0, 0));
		button_1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 16));
		button_1.setBackground(new Color(176, 196, 222));
		contentPane.add(button_1);
		
		JLabel label_7 = new JLabel("All rights reserved.");
		label_7.setBounds(584, 700, 192, 25);
		label_7.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_7.setForeground(new Color(0, 0, 51));
		contentPane.add(label_7);
		
		JLabel label_8 = new JLabel("\u00A9 2018");
		label_8.setBounds(639, 725, 77, 25);
		label_8.setFont(new Font("Tahoma", Font.BOLD, 20));
		label_8.setForeground(new Color(0, 0, 51));
		contentPane.add(label_8);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 39, 1347, 40);
		contentPane.add(separator);
		
		JLabel label_5 = new JLabel("WELCOME TO FPI RESULT MANAGEMENT SYSTEM");
		label_5.setBounds(382, 510, 558, 30);
		label_5.setForeground(new Color(51, 51, 255));
		label_5.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 25));
		label_5.setBackground(new Color(106, 90, 205));
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("Click on the apropriate button to continue");
		label_6.setBounds(368, 551, 592, 39);
		label_6.setForeground(new Color(51, 102, 0));
		label_6.setFont(new Font("Arabic Typesetting", Font.BOLD, 30));
		label_6.setBackground(new Color(106, 90, 205));
		contentPane.add(label_6);
		
		JLabel label_9 = new JLabel("");
		label_9.setBounds(668, 451, 48, 48);
		label_9.setVerticalAlignment(SwingConstants.TOP);
		label_9.setIcon(new ImageIcon("C:\\Users\\ABAH JOSEPH ISRAEL\\eclipse-workspace\\Fpi_Result_Management\\src\\img\\icons8_Search_48px.png"));
		contentPane.add(label_9);
		
		JButton btnExit = new JButton("X");
		btnExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Component quit = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(quit, "Do you want to exit", "Result Management Systems", JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnExit.setHorizontalAlignment(SwingConstants.LEADING);
		btnExit.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnExit.setForeground(new Color(255, 0, 0));
		btnExit.setBackground(new Color(204, 153, 0));
		btnExit.setBounds(1305, 10, 44, 24);
		contentPane.add(btnExit);
		
		JLabel lblDeveloper = new JLabel("Developer");
		lblDeveloper.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Developer Joh = new Developer();
				Joh.setVisible(true);
				//dispose();
			}
		});
		lblDeveloper.setBackground(Color.BLUE);
		lblDeveloper.setForeground(Color.ORANGE);
		lblDeveloper.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblDeveloper.setBounds(616, 669, 118, 29);
		contentPane.add(lblDeveloper);
		
		JLabel lblResultManagementSystem = new JLabel("RESULT MANAGEMENT SYSTEM");
		lblResultManagementSystem.setForeground(new Color(47, 79, 79));
		lblResultManagementSystem.setFont(new Font("Arial Black", Font.BOLD, 25));
		lblResultManagementSystem.setBounds(435, 0, 469, 46);
		contentPane.add(lblResultManagementSystem);
		setTitle("FPI Result System");
		setUndecorated(true);
	}
}
